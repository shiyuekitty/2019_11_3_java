public class Japan implements Computable {
    int number;

    @Override
    public int f(int x) {
        return 64+x;
    }
}
