class Miqilin implements TyresStandard {
    @Override
    public void turnWhell() {
        System.out.println("轮胎大小是："+TyresStandard.size);
        System.out.println("轮胎正常转动，最大转数：2888/m");
    }

    @Override
    public String getTyresName() {
        return "品牌是米其林";
    }
}
