public class Example6_4 {
    public static void main(String[] args) {
        Car car=new Car();
        car.useTyres(new Miqilin());
        car.useTyres(new Puliston());
    }
}
