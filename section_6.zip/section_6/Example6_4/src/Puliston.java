class Puliston implements TyresStandard {

    @Override
    public void turnWhell() {
        System.out.println("轮胎大小是："+TyresStandard.size);
        System.out.println("轮胎正常转动，最大转数：2567/m");
    }

    @Override
    public String getTyresName() {
        return "品牌是普利司通";
    }
}

