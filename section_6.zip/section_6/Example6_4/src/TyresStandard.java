public interface TyresStandard {
    public final int size=17;
    public void turnWhell();
    public String getTyresName();
}
