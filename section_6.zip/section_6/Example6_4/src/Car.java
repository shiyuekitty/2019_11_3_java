public class Car {
    public void useTyres(TyresStandard tyres){
        System.out.println(tyres.getTyresName());
        tyres.getTyresName();
        tyres.turnWhell();
    }
}
