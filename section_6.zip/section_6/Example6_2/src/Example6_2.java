interface ShowMessage{
    void show(String s);
}
class TV implements ShowMessage{

    @Override
    public void show(String s) {
        System.out.println("*******");
        System.out.println(s);
        System.out.println("******");
    }
}
class PC implements ShowMessage{

    @Override
    public void show(String s) {
        System.out.println("@@@@@@");
        System.out.println(s);
        System.out.println("@@@@@@");
    }
}
public class Example6_2 {
    public static void main(String[] args) {
        ShowMessage sm;
        sm=new TV();
        sm.show("金星牌电视机");
        sm=new PC();
        sm.show("高速牌计算机");
    }
}
