public class BankBook{
	String name;
	String indentifyCard;
	String homeAddress;
	double money;
	String date;
	Boolean presentPassword;
	String Password;

	BankBook(String indentifyCard,String name,String homeAddress,double money){
		this.name=name;
		this.indentifyCard=indentifyCard;
		this.homeAddress=homeAddress;
		this.money=money;

	}
	public void show(){
		System.out.println("������Ϣ:");
        	System.out.println("����:"+name);
        	System.out.println("����֤:"+indentifyCard);
        	System.out.println("סַ:"+homeAddress);
		System.out.println("���:"+money);
	

	}

	public static void main(String args[]){
		BankBook bankBook=new BankBook("112131535","����","����",5000.00);
		bankBook.show();
		
	}
}

