public class Person{                        
    String name;
    int age;
    String sex;
    double weight;
    double height;

    public void setname(String name){
        this.name=name;
    }
    public void setage(int age){
        this.age=age;
    }
    public void setsex(String sex){
        this.sex=sex;
    }
    public void setweight(double weight){
        this.weight=weight;
    }
    public void setheight(double height){
        this.height=height;
    }

    public String getName(){
        return name;
    }
    public int getage(){
        return age;
    }
    public String getsex() {
        return sex;
    }
    public double getweight() {
        return weight;
    }
    public double getheight(){
        return height;
    }

    public static void main(String args[]){
        Person person=new Person();
        person.setname("shiyue");
        person.setage(18);
	    person.setsex("man");
        person.setweight(50.0);
        person.setheight(180.0);

        String tname=person.getName();
        int tage=person.getage();
        String tsex=person.getsex();
        double tweight=person.getweight();
        double theight=person.getheight();

        System.out.println("name:"+tname);
        System.out.println("age:"+tage);
        System.out.println("sex:"+tsex);
        System.out.println("weight:"+tweight+"KG");
        System.out.println("height:"+theight+"CM");
    }
}
