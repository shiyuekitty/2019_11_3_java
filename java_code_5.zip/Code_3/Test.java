class Trangle {

    double sideA, sideB, sideC, area, length;
    boolean boo;

    public Trangle(double a, double b, double c) {
        this.sideA = a;
        this.sideB = b;
        this.sideC = c;

        if (sideA + sideB > sideC && sideB + sideC > sideA && sideA + sideC > sideB)
        {
            boo = true;
        } else {
            boo = false;
        }
    }

    public double getLength() {
        length = sideA + sideB + sideC;
        return length;
    }

    public double getArea() {

        if (boo) {

            double p = (sideA + sideB + sideC) / 2.0;

            area = Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));

            return area;

        } else {

            System.out.println("����һ��������,���ܼ������");

            return 0;

        }

    }

    public void setABC(double a, double b, double c) {

        this.sideA = a;
        this.sideB = b;
        this.sideC = c;

        if (a + b > c && b + c > a && a + c > b)

        {
            boo = true;

        } else {
            boo = false;

        }

    }

}

class Lader {

    double above, bottom, height, area;
    Lader(double a,double b,double h)

    {
        this.above=a;
        this.bottom=b;
        this.height=h;

    }

    public double getArea() {
        area = (above + bottom) * height / 2;
        return area;
    }

}


class Circle {

    double radius, area, length;

    Circle(double r) {
        radius = r;

    }

    double getArea() {
        area = Math.PI*radius*radius;
        return area;

    }

    double getLength() {
        length = 2*Math.PI*radius;
        return length;

    }

    void setRadius(double newRadius) {

        radius = newRadius;

    }

    double getRadius() {

        return radius;

    }

}

public class Test {

    public static void main(String args[]) {

        double length, area;

        Circle circle = new Circle(5.00);

        Trangle trangle = new Trangle(3,4,5);

        Lader lader = new Lader(2,4,2);

        length = circle.getLength();

        System.out.println("Բ���ܳ�:" + length);

        area = circle.getArea();

        System.out.println("Բ�����:" + area);

        length = trangle.getLength();

        System.out.println("�����ε��ܳ�:" + length);

        area = trangle.getArea();

        System.out.println("�����ε����:" + area);

        area = lader.getArea();

        System.out.println("���ε����:" + area);

        trangle.setABC(12.00, 34.00, 1.00);

        area = trangle.getArea();

        System.out.println("�����ε����:" + area);

        length = trangle.getLength();

        System.out.println("�����ε��ܳ�:" + length);
    }
}