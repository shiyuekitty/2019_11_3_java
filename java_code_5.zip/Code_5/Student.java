﻿import java.util.Scanner;
class Student {
    private int no;
    private static int age;
    private String name;
    private String sex;
    public void setAge(int myAge) {
        if(myAge>=10||myAge<=50) {
            age=myAge;
        } 
        else {
            System.out.println("年龄合法");
            age=myAge;
        }
    }   
    public void setSex(String mySex){
        if(mySex=="男"||mySex=="女"){
            sex=mySex;
        }
        else {
            System.out.println("性别合法 ");
            sex=mySex;
        }
    }
    public int getNo() { 
        System.out.println("学号："+no);
        return no;
    }
    public String getName(){ 
        System.out.println("姓名："+name); 
        return name;
    } 
    public String getSex(){ 
        System.out.println("性别："+sex); 
        return sex;
    }
    public int getAge() {
        System.out.println("年龄："+age);
        return age;
    }
    public Student(int myNo, String  myName, String mySex, int myAge) {
        no = myNo;        
        name = myName;        
        sex = mySex;        
        age = myAge;    
    }         
    
    public static void main(String[] args) {
        Scanner reader=new Scanner(System.in);
        int no=reader.nextint();
        int age=reader.nextint();

        Student Student1= new Student(1625,"张三","m",20);
        Student1.setAge(age);
        Student1.getNo();
        Student1.getName();
        Student1.getSex();
        Student1.getAge();
           
    } 
}
