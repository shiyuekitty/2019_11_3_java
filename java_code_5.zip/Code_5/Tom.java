class Tom{
    protected float weight;
    protected float f(float a,float b){
        return a+b;
    }
}