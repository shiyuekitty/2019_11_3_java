class Area{
    private static final double PI = 3.14;
    private double area;
    Area(double length,double wide){
         area=length*wide;

    }
    Area(double redius){
         area=3.14*redius*redius;

    }
    Area(double length,double wide,double height){
        area=(length+wide)*height/2;
        
    }
    public void showArea(){
        System.out.println(String.format("%.2f", area));
    }
}
public class AreaDemo {
    public static void main(String[] args) {
        Area rectangle = new Area(3.0, 5.5);
        Area cycle = new Area(2.4);
        Area echelon = new Area(3.2, 4.5, 4);
        System.out.print("rectangle area:");
        rectangle.showArea();
        System.out.print("cycle area:");
        cycle.showArea();
        System.out.print("echelon area:");
        echelon.showArea();
    }
}
