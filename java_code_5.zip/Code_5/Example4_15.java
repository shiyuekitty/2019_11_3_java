public class Example4_15{
    public static void main(String[] args) {
        Yuan circle=new Yuan();
        circle.setRadius(123);
        System.out.println("circle的半径:"+circle.getRadius());
        circle.setRadius(-523);
        System.out.println("circle的半径:"+circle.getRadius());
    }
}