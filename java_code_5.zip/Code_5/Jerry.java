class Jerry{
    public static void main(String[] args) {
        Tom cat=new Tom();
        cat.weight=23f;
        float sum=cat.f(3,4);
        System.out.printf("sum:"+sum);
    }
}