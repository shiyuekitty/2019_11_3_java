package test_01;

public class Bclass {
    public void show(){
        Aclass a = new Aclass();
//        a.showA1();
        a.showA2();
        a.showA3();
        a.showA4();
//        showA1();
//        showA2();
//        showA3();
//        showA4();
//        System.out.println(a.a1);
        System.out.println(a.a2);
        System.out.println(a.a3);
        System.out.println(a.a4);
//        System.out.println(a1);
//        System.out.println(a2);
//        System.out.println(a3);
//        System.out.println(a4);
    }

    public static void main(String[] args) {
        Bclass b=new Bclass();
        b.show();
    }
}
