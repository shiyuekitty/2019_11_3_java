
public class Example4_6{
	public static void main(String args[]){
		Circle circle=new Circle();
		circle.radius=100;
		Circular circular=new Circular();
		circular.setbottom(circle);
		circular.setHeight(6.66);
		System.out.printf("Բ׶�����:%5.3f\n",circular.getVolme());
	}
}