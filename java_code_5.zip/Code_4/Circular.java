class Circle{
	double radius;
	
	double getArea(){
		double area=3.14*radius*radius;
		return area;
	}
}
public class Circular{
	Circle bottom;
	double height;
	void setbottom(Circle c){
		bottom=c;
	}
	void setHeight(double h){
		height=h;
	}
	double getVolme(){
		return bottom.getArea()*height/3.0;
	}
}