class Administrator {
    String name;
    String password;// ����

    public void show() {
        System.out.println("����" + name + "����" + password);
    }

}

import java.util.Scanner;
public class ChangePassword {
    public static void main(String []args){
        String nameInput;
        String Pwd;
        String pwdConfirm;
        Scanner input=new Scanner(System.in);
        Administrator admin=new Administrator();
        admin.name="admin1";
        admin.password="123456";
        System.out.println("Please enter your name :\n");
        nameInput=input.next();
        System.out.println("Please enter your password:\n");
        Pwd=input.next();
        if(admin.name.equals(nameInput)&&admin.password.equals(Pwd)){
            System.out.println("Please enter new Pwd:\n");
            Pwd=input.next();
            System.out.println("Please enter new Pwd again:\n");
            pwdConfirm=input.next();
            while(!Pwd.equals(pwdConfirm))
            {
                System.out.println("Please enter new Pwd again:\n");
                System.out.println("Please enter new Pwd:\n");
                Pwd=input.next();
                System.out.println("Please enter new Pwd again:\n");
                pwdConfirm=input.next();
            }
            System.out.println("SUCCESS, your new pwd is "+Pwd);
        System.out.println("�û�����"+admin.name+"���룺"+Pwd);
       
        
        }
        else{
            System.out.println("the usename is not match the pwd:\n");
            
            
        }
        
    }
    
}