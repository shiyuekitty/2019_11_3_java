import java.util.Scanner;
class Administrator {
    String name;
    String password;// ?¨¹??

    

}


public class ChangePassword {
    public static void main(String []args){
        String nameInput;
        String Pwd;
        String pwdConfirm;
        Scanner input=new Scanner(System.in);
        Administrator admin=new Administrator();
        admin.name="admin1";
        admin.password="111111";
        System.out.println("请输入姓名 :");
        nameInput=input.next();
        System.out.println("请输入密码:");
        Pwd=input.next();
        if(admin.name.equals(nameInput)&&admin.password.equals(Pwd)){
            System.out.println("修改密码成功，请输入新密码:");
            Pwd=input.next();
            
       
        
        }
        else{
            System.out.println("用户名和密码不匹配:");
            
            
        }
        
    }
    
}