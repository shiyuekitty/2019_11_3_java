public class Card{
	private char suit;
	private String rank;
	public Card(char suit,String rank){
		this.suit=suit;
		this.rank=rank;
	}
	public String toString(){
		return suit+rank;
	}
	public static void main(String[] args){
		Card c=new Card('��',"10");
		System.out.println(c.toString());
	}
}