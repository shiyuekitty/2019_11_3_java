package com;
interface shuaka{
    void show(int money);

}
class oldCard implements shuaka{
	public void show(int money){
        System.out.println("收费"+money);
        System.out.println("老人卡");
    }
}
class student implements shuaka{
    public void show(int money){
        System.out.println("学生卡");
    }
}
public class TestCard {
    public static void main(String[] args) {
        shuaka sh;
        sh=new oldCard();
        sh.show(2);
        sh=new student();
        sh.show(2);
    }
}
