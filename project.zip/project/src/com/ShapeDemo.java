package com;



class Circle extends ShapeDemo{
    double r;
	
    Circle(double r,String str){
		this.r =r;
	}
	public String toString(){
		double zhouchang;
		double Area;
		zhouchang=2*3.14*r;
		Area=3.14*r*r;
		return("圆形"+zhouchang+","+Area);
	}
	
}
class Square extends ShapeDemo{
	double a,b;
	Square(double a,String leixing){
		this.a =a;
	}
	public String toString(){
		double zhouchang,Area;
		zhouchang=a*4;
		Area=a*a;
		return("正方形"+zhouchang+","+Area);
	}
}
class Triangle extends ShapeDemo{
	double m,n,q;
	Triangle(double m,double n,double q,String leixing){
		this.m =m;
		this.n =n;
		this.q =q;
	}
	public String toString(){
		double zhouchang,Area;
		zhouchang=m+n+q;
		double p=zhouchang/2*(zhouchang/2-m)*(zhouchang/2-n)*(zhouchang/2-q);
		Area=Math.sqrt(p);
		return("三角形"+zhouchang+","+Area);
	}
}


public class ShapeDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ShapeDemo s1=null;
        s1=new Circle(5, "圆形");
        System.out.println(s1.toString());

        s1=new Square(6, "正方形");
        System.out.println(s1.toString());

        s1=new Triangle(3,4,5,"三角形");
        System.out.println(s1.toString());
	}

}
