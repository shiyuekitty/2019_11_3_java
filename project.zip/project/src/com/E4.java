package com;

interface Jump {
	public void ShowJump(); 
}

interface Fly {
	public void ShowFly(); 
}
class Losust implements Fly,Jump{
	public void ShowFly(){
		System.out.println("Locust can Fly");
	}
	public void ShowJump(){
		System.out.println("Locust can Jump");
	}
}
class Balloon implements Fly{
	public void ShowFly(){
		System.out.println("Balloon can Fly");
	}
}

public class E4 {

	/**
	 * @param args
	 */
	public static void main(String args[])
	{
		Fly fly;
		Jump jump;
		fly=new Losust();
		jump=new Losust();
		fly.ShowFly();
		jump.ShowJump();
		fly=new Balloon();
		fly.ShowFly();
	}

}
