package com;
class Animal{
    public int month = 2;
    public void eat(){
        System.out.println("����Զ���");
    }
	
}

class Dog extends Animal{
   public int month = 3;
   
   public void eat() {
       System.out.println("С������");
   }
   
   public void sleep() {
       System.out.println("С��˯���");
   }
}

class Cat extends Animal{
   public int month = 4;
   
   public void eat() {
       System.out.println("Сè����");
   }
}


public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Animal a = new Dog();
        Animal b = new Cat();
        a.eat();
        System.out.println(a.month);
        Dog d=new Dog();
        d.sleep();
        b.eat();
        System.out.println(b.month);  


	}

}
