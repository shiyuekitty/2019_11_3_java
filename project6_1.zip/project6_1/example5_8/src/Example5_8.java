class People{
    String name;
    void showname(){
        System.out.println("***\n");
    }
}
class American extends People{
    void showname(){
        System.out.println("美国人姓名是名在前姓在后："+name);
    }
    void speakEnglish(){
        System.out.println("how are you");
    }
}
class Chinese extends People{
    void showname(){
        System.out.println("中国人姓名是姓在前名在后："+name);
    }
    void speakname(){
        System.out.println("您好");
    }
}
public class Example5_8 {
    public static void main(String[] args) {
        People people=null;
        American american=new American();
        people=american;
        people.name="MadingSun.Lee";
        people.showname();
        american.speakEnglish();
        Chinese chinese=new Chinese();
        people=chinese;
        people.name="张三林";
        people.showname();
        chinese.speakname();
    }
}
