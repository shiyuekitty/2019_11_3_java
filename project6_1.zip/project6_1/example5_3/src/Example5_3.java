class A{
    public double n=3.89;
    public double getHiddenN(){
        return n;
    }
}
class B extends A{
    public int n;
    public int getN(){
        return n;
    }
}
public class Example5_3 {
    public static void main(String[] args) {
        B b=new B();
        b.n=18;
        System.out.println("对象b的值是："+b.getN());
        System.out.println("对象b隐藏的n的值是："+b.getHiddenN());
    }
}
