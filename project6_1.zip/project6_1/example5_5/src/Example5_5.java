public class Example5_5 {

    public static void main(String[] args) {
        // TODO Auto-generated method stub
        int amount=8000;
        ConstructionBank bank=new ConstructionBank();
        bank.savedMoney=amount;
        bank.year=5.216;
        double interest=bank.computerInterest();
        System.out.printf("利息是%5.3f元\n",interest);
    }

}