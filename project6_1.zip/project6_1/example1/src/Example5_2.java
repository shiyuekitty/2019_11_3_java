class A{
    private int x=100;
    public int getX(){
        return x;
    }
    public void setX(int x){
        this.x=x;
    }
}
class B extends A{
    int y=200;
}

public class Example5_2 {
    public static void main(String[] args) {
        B b=new B();
        System.out.println("对象b未继承的x的值是："+b.getX());
        b.setX(888);
        System.out.println("对象b调用继承的方法修改了未继承的x的值.");
        System.out.println("目前对象b未继承的x的值是："+b.getX());
        System.out.println("对象b新增的y的值是："+b.y);
    }
}
