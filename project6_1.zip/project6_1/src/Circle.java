public class Circle {
    public double radius;

    Circle() {
        radius = 0;
    }

    Circle(double r) {
        this.radius = r;
    }

    double getArea() {
        double area = Math.PI * radius * radius;
        return area;
    }

    double getPerimeter() {
        double perimeter = 2 * Math.PI * radius;
        return perimeter;
    }

    void disp() {
        System.out.println("radius=" + radius);
        System.out.println("perimeter=" + getPerimeter());
        System.out.println("area=" + getArea());
    }
}
