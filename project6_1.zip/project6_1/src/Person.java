public class Person {
    public String name = "dfdf";
    public int age = 15;
    //public char sex='man';

    public void Person(String name, int age, char sex) {
        this.name = name;
        this.age = age;
//        this.sex = sex;
    }

    public void Pshow() {
        System.out.println("name:" + name);
        System.out.println("age:" + age);
        //System.out.println("sex"+sex);
    }
}
