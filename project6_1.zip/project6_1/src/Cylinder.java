import java.util.Scanner;

public class Cylinder extends Circle {
    public double height;

    Cylinder(double r, double h) {
        this.radius = r;
        this.height = h;
    }

    double getHeight() {
        return height;
    }

    double getVol() {
        double vol = getArea() * height;
        return vol;
    }

    void dispVol() {
        System.out.println("Vol:" + getVol());
    }

    public static void main(String[] args) {
        Scanner reader = new Scanner(System.in);
        int i = 1;
        System.out.println("圆的半径：");
        double r = reader.nextDouble();
        System.out.println("圆柱体的高：");
        double h = reader.nextDouble();
        while (i == 1) {
            if (r > 0 && h > 0) {
                i = 0;
                break;
            }
            System.out.println("圆的半径：");
            r = reader.nextDouble();
            System.out.println("圆柱体的高：");
            h = reader.nextDouble();
        }
        if (i == 0) {
            Circle c = new Circle(r);
            Cylinder d = new Cylinder(r, h);
            c.disp();
            d.dispVol();
        }
    }
}

