public class Student extends Person{
    public String sno = "154";
    public int classno = 15454;

    public void Student() {
        this.sno = sno;
        this.classno = classno;
    }

    public void show() {
        Person p = new Person();
        p.Pshow();
        System.out.println("sno:" + sno);
        System.out.println("classno:" + classno);
    }

    public static void main(String[] args) {
        Student p = new Student();

        p.show();
    }
}
